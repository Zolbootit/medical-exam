import type { Metadata } from "next";
import "./globals.css";
import Link from "next/link";

export const metadata: Metadata = {
  title: "MedPrep Mongolia | Шалгалтад бэлд",
  description: "Анагаахын шалгалтад бэлтгэх, ахицаа хянах платформ."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="mn">
      <body>
        <header className="topbar">
          <Link className="brand" href="/"><span className="brand-mark">+</span><span>MedPrep<span className="brand-light"> Mongolia</span></span></Link>
          <nav>
            <Link href="/">Нүүр</Link>
            <Link href="/practice">Дасгал</Link>
            <Link href="/exam">Шалгалт</Link>
            <Link href="/mistakes">Алдсан асуулт</Link>
            <Link className="nav-cta" href="/import">Асуулт нэмэх</Link>
          </nav>
        </header>
        <main>{children}</main>
        <footer className="footer"><span>MedPrep Mongolia</span><span>Суралцахад хялбар. Ахиц тодорхой.</span></footer>
      </body>
    </html>
  );
}
