 "use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";

type Q = { id: string; category: string; question: string; options: string[]; correctAnswer: number; explanation: string };
const sample: Q[] = [
 {id:"demo-1",category:"Дотор өвчин",question:"Энэ бол интерфэйсийг турших зориулалттай жишээ асуулт. Жинхэнэ асуултын санг оруулахдаа эмнэлзүйн үнэн зөв мэдээллээр солих шаардлагатай.",options:["Сонголт A","Сонголт B","Сонголт C","Сонголт D"],correctAnswer:1,explanation:"Энэ нь зөвхөн системийн ажиллагааг шалгах demo тайлбар. Бодит анагаахын зөвлөгөө биш."},
 {id:"demo-2",category:"Хүүхэд судлал",question:"Суралцах явцад алдсан асуултаа яах нь хамгийн хэрэгтэй вэ?",options:["Дахиж хэзээ ч харахгүй байх","Зөв хариултыг ойлгож, дараа нь дахин давтах","Зөвхөн асуултын дугаарыг цээжлэх","Бүх асуултад таамгаар хариулах"],correctAnswer:1,explanation:"Алдаагаа ойлгож, зайтай давтах нь мэдлэгээ бататгахад тусалдаг."},
 {id:"demo-3",category:"Шалгалтын арга",question:"Сэдэвчилсэн дасгалын гол зорилго юу вэ?",options:["Сул сэдвээ илрүүлж, ойлголтоо бататгах","Зөвхөн хурдан дарах","Асуултын тоог харах","Тайлбар уншихгүй байх"],correctAnswer:0,explanation:"Сэдэвчилсэн дасгал нь мэдлэгийн сул талыг тодорхойлоход тусална."}
];
function getQuestions(): Q[] { try { const raw=localStorage.getItem("medprep_questions"); if(raw){const parsed=JSON.parse(raw); if(Array.isArray(parsed)&&parsed.length)return parsed;} } catch {} return sample; }
export default function PracticePage(){
 const [questions,setQuestions]=useState<Q[]>(sample); const [idx,setIdx]=useState(0); const [selected,setSelected]=useState<number|null>(null); const [checked,setChecked]=useState(false); const [filter,setFilter]=useState("Бүх сэдэв");
 useEffect(()=>{setQuestions(getQuestions());},[]);
 const categories=useMemo(()=>["Бүх сэдэв",...Array.from(new Set(questions.map(q=>q.category)))],[questions]);
 const filtered=useMemo(()=>filter==="Бүх сэдэв"?questions:questions.filter(q=>q.category===filter),[questions,filter]);
 const q=filtered[idx];
 function check(){if(selected===null)return;setChecked(true);try{const raw=JSON.parse(localStorage.getItem("medprep_attempts")||"[]");raw.push({id:q.id,correct:selected===q.correctAnswer,at:Date.now()});localStorage.setItem("medprep_attempts",JSON.stringify(raw));if(selected!==q.correctAnswer){const mistakes=JSON.parse(localStorage.getItem("medprep_mistakes")||"[]");if(!mistakes.some((m:Q)=>m.id===q.id))mistakes.push(q);localStorage.setItem("medprep_mistakes",JSON.stringify(mistakes));}else{const mistakes=JSON.parse(localStorage.getItem("medprep_mistakes")||"[]");localStorage.setItem("medprep_mistakes",JSON.stringify(mistakes.filter((m:Q)=>m.id!==q.id)));}}catch{}}
 function next(){setIdx((idx+1)%filtered.length);setSelected(null);setChecked(false);}
 return <div className="container"><div className="page-title"><h1>Сэдэвчилсэн дасгал</h1><p>Нэг асуултад төвлөр. Хариултаа шалгаад тайлбарыг унш.</p></div>
 <div className="toolbar"><select className="select" value={filter} onChange={e=>{setFilter(e.target.value);setIdx(0);setSelected(null);setChecked(false);}}>{categories.map(c=><option key={c}>{c}</option>)}</select><span className="muted small" style={{alignSelf:"center"}}>{filtered.length} асуулт</span></div>
 {!q?<div className="empty">Энэ сэдэвт асуулт алга. <Link className="text-link" href="/import">Асуулт импортлох →</Link></div>:<div className="question-card"><div className="question-top"><span className="tag">{q.category}</span><span>{idx+1} / {filtered.length}</span></div><h2>{q.question}</h2>{q.options.map((o,i)=><button key={i} disabled={checked} className={`option ${selected===i?"selected":""} ${checked&&i===q.correctAnswer?"correct":""} ${checked&&selected===i&&selected!==q.correctAnswer?"wrong":""}`} onClick={()=>setSelected(i)}><span className="option-letter">{String.fromCharCode(65+i)}</span><span>{o}</span></button>)}
 {checked&&<div className={`feedback ${selected===q.correctAnswer?"good":"bad"}`}><strong>{selected===q.correctAnswer?"Зөв хариуллаа!":"Дахин судлаарай."}</strong><div>{q.explanation||"Энэ асуултад тайлбар нэмэгдээгүй байна."}</div></div>}
 <div className="question-actions">{checked?<button className="btn btn-secondary" onClick={next}>Дараагийн асуулт →</button>:<button className="btn btn-primary" disabled={selected===null} onClick={check}>Хариулт шалгах</button>}<Link className="btn btn-secondary" href="/mistakes">Алдсан асуултууд</Link></div></div>}
 <div className="notice">Энэ багцад туршилтын асуултууд бий. Эмнэлзүйн агуулгыг мэргэжлийн эх сурвалжаар баталгаажуулж байж шалгалтын сан болгон ашиглаарай.</div>
 </div>;
}
