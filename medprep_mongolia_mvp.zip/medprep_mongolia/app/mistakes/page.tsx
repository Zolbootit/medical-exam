 "use client";
import { useEffect, useState } from "react";
import Link from "next/link";
type Q={id:string;category:string;question:string;options:string[];correctAnswer:number;explanation:string};
export default function MistakesPage(){const [items,setItems]=useState<Q[]>([]);useEffect(()=>{try{setItems(JSON.parse(localStorage.getItem("medprep_mistakes")||"[]"));}catch{}},[]);
function remove(id:string){const next=items.filter(q=>q.id!==id);setItems(next);localStorage.setItem("medprep_mistakes",JSON.stringify(next));}
return <div className="container"><div className="page-title"><h1>Алдсан асуултууд</h1><p>Энд буруу хариулсан асуултууд хадгалагдана. Дахин ойлгож, бататгаарай.</p></div>{items.length===0?<div className="empty"><div style={{fontSize:35,marginBottom:12}}>🌱</div><strong>Одоогоор хадгалсан алдаа алга.</strong><p>Дасгал ажиллах үед буруу хариулсан асуултууд энд гарч ирнэ.</p><Link className="btn btn-primary" href="/practice">Дасгал эхлүүлэх →</Link></div>:items.map(q=><div className="panel" key={q.id} style={{marginBottom:14}}><div className="question-top"><span className="tag">{q.category}</span><button className="text-link" onClick={()=>remove(q.id)}>Жагсаалтаас хасах</button></div><h3>{q.question}</h3><p><strong>Зөв хариулт:</strong> {q.options[q.correctAnswer]}</p><p className="muted">{q.explanation}</p></div>)}</div>}
