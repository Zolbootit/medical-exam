import Link from "next/link";

const topics = [
  { icon: "🫀", title: "Дотор өвчин", desc: "Оношилгоо, эмчилгээний үндсэн ойлголтууд.", count: "Сэдэвчилсэн дасгал" },
  { icon: "🩺", title: "Мэс засал", desc: "Мэс заслын тусламж, хүндрэл, анхан шатны мэдлэг.", count: "Сэдэвчилсэн дасгал" },
  { icon: "👶", title: "Хүүхэд судлал", desc: "Хүүхдийн өсөлт, хөгжил, түгээмэл өвчнүүд.", count: "Сэдэвчилсэн дасгал" },
  { icon: "🤰", title: "Эх барих, эмэгтэйчүүд", desc: "Жирэмслэлт, төрөлт, эмэгтэйчүүдийн эрүүл мэнд.", count: "Сэдэвчилсэн дасгал" },
  { icon: "🧠", title: "Мэдрэл судлал", desc: "Мэдрэлийн тогтолцоо, шинж тэмдэг, үнэлгээ.", count: "Сэдэвчилсэн дасгал" },
  { icon: "🧪", title: "Бусад сэдэв", desc: "Өөрийн асуултын сангаар сэдвүүдийг өргөжүүлнэ.", count: "Өөрийн сангаа нэмэх" }
];

export default function Home() {
  return (
    <div className="container">
      <section className="hero">
        <div>
          <div className="eyebrow"><span className="eyebrow-dot" /> Шалгалтад бэлтгэх шинэ арга</div>
          <h1>Зүгээр цээжлэх биш, <em>ойлгож</em> бэлд.</h1>
          <p className="lead">Анагаахын шалгалтад бэлдэхэд хэрэгтэй асуулт, тайлбар, давтлагаа нэг дороос. Өөрийн сул сэдвийг олж, алхам бүрээр ахицаа нэмэгдүүл.</p>
          <div className="actions">
            <Link className="btn btn-primary" href="/practice">Дасгал эхлүүлэх <span>→</span></Link>
            <Link className="btn btn-secondary" href="/exam">Шалгалт өгөх</Link>
          </div>
        </div>
        <div className="hero-card">
          <div className="card-top"><span>Өнөөдрийн зорилго</span><span className="live-pill">✦ Төлөвлөгөө</span></div>
          <h3>Өдөр бүр бага багаар ахиц гарга.</h3>
          <p>10 асуулт ажилла. Алдсан асуултаа дахин үз. Өөрийн мэдлэгээ шалга.</p>
          <div className="progress-label"><span>Өдөр тутмын зорилго</span><strong>0 / 10</strong></div>
          <div className="progress"><span style={{width:"0%"}} /></div>
          <div className="mini-stats">
            <div className="mini-stat"><b>10</b><span>Өдрийн асуулт</span></div>
            <div className="mini-stat"><b>∞</b><span>Давтах боломж</span></div>
            <div className="mini-stat"><b>1%</b><span>Өдөр бүр ахих</span></div>
          </div>
        </div>
      </section>

      <section className="stats-grid">
        <div className="stat-card"><div className="stat-icon">📚</div><strong>Өөрийн сан</strong><span>Асуултаа импортолж, ангилж болно.</span></div>
        <div className="stat-card"><div className="stat-icon">🎯</div><strong>Зорилтот давтлага</strong><span>Алдсан асуултаа тусад нь ажилла.</span></div>
        <div className="stat-card"><div className="stat-icon">📈</div><strong>Ахицын хяналт</strong><span>Шалгалтын оноо, зөв хариултаа хар.</span></div>
      </section>

      <section>
        <div className="section-head"><div><h2>Сэдвээ сонго</h2><p>Тодорхой нэг чиглэлээс эхлээд мэдлэгээ бататга.</p></div><Link className="text-link" href="/practice">Бүх дасгал →</Link></div>
        <div className="topic-grid">{topics.map((t) => <Link href="/practice" className="topic-card" key={t.title}><div className="topic-icon">{t.icon}</div><h3>{t.title}</h3><p>{t.desc}</p><div className="topic-meta"><span>{t.count}</span><span>↗</span></div></Link>)}</div>
      </section>

      <section className="callout"><div><h2>Өөрийн асуултын сангаа нэм</h2><p>JSON файлаас асуулт импортолж, нэг дор ажиллуулах боломжтой.</p></div><Link className="btn btn-primary" href="/import">Асуулт импортлох →</Link></section>
      <p className="small muted" style={{marginTop:22}}>Тайлбар: Одоогийн хувилбар нь туршилтын загвар. Энд бодит шалгалтын албан ёсны асуултын сан хараахан ороогүй.</p>
    </div>
  );
}
